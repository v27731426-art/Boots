package com.ragebots;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class BotsScreen extends Screen {
    private static String lastNick = "bot" + (100 + (int) (Math.random() * 900));
    private static String lastHost = "play.funtime.su";

    private Bot selected;
    private int scroll = 0;

    private int leftW, rx, rw;
    private int chatTop, chatBottom;
    private float capScale;
    private int capOx, capOy, capOw, capOh, capImgSize;

    private TextFieldWidget nickField, hostField, chatField, captchaField, slotField;
    private ButtonWidget fishBtn, capOk, capHide;
    private final List<Bot> shownBots = new ArrayList<>();

    public BotsScreen(Bot sel) {
        super(Text.literal("Боты"));
        this.selected = sel;
        if (selected == null && !BotManager.bots.isEmpty()) selected = BotManager.bots.get(0);
    }

    private ButtonWidget btn(String label, int x, int y, int w, int h, Runnable action) {
        return addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(x, y, w, h).build());
    }

    @Override
    protected void init() {
        leftW = Math.min(130, Math.max(90, width / 4));
        rx = leftW + 10;
        rw = width - rx - 4;

        // ----- список ботов -----
        shownBots.clear();
        int y = 4;
        int maxBots = Math.max(1, (height - 64 - 4) / 17);
        for (Bot b : BotManager.bots) {
            if (shownBots.size() >= maxBots) break;
            shownBots.add(b);
            final Bot bb = b;
            btn("    " + b.name, 4, y, leftW, 16, () -> client.setScreen(new BotsScreen(bb)));
            y += 17;
        }

        // ----- добавление бота -----
        int ay = height - 52;
        nickField = new TextFieldWidget(textRenderer, 4, ay, leftW, 14, Text.literal("ник"));
        nickField.setMaxLength(16);
        nickField.setText(lastNick);
        addDrawableChild(nickField);
        hostField = new TextFieldWidget(textRenderer, 4, ay + 16, leftW, 14, Text.literal("сервер"));
        hostField.setMaxLength(100);
        hostField.setText(lastHost);
        addDrawableChild(hostField);
        btn("+ Добавить бота", 4, ay + 32, leftW, 16, this::addBot);

        // ----- кнопки управления -----
        int gap = 3;
        int n = 5;
        int bw = (rw - gap * (n - 1)) / n;
        int by = 16;
        fishBtn = btn("Рыбалка", rx, by, bw, 16, () -> {
            if (selected != null) selected.setFishing(!selected.fishing);
        });
        btn("Всем: вкл", rx + (bw + gap), by, bw, 16, () -> {
            for (Bot b : BotManager.bots) if (b.inGame && !b.fishing) b.setFishing(true);
        });
        btn("Всем: выкл", rx + 2 * (bw + gap), by, bw, 16, () -> {
            for (Bot b : BotManager.bots) if (b.fishing) b.setFishing(false);
        });
        btn("Подключить", rx + 3 * (bw + gap), by, bw, 16, () -> {
            if (selected != null) selected.connectAsync();
        });
        btn("Удалить", rx + 4 * (bw + gap), by, bw, 16, () -> {
            if (selected != null) {
                BotManager.remove(selected);
                client.setScreen(new BotsScreen(null));
            }
        });

        int n2 = 6;
        int bw2 = (rw - gap * (n2 - 1)) / n2;
        int by2 = 34;
        btn("Влево", rx, by2, bw2, 16, () -> {
            if (selected != null) selected.look(-20f, 0f);
        });
        btn("Вправо", rx + (bw2 + gap), by2, bw2, 16, () -> {
            if (selected != null) selected.look(20f, 0f);
        });
        btn("Вверх", rx + 2 * (bw2 + gap), by2, bw2, 16, () -> {
            if (selected != null) selected.look(0f, -10f);
        });
        btn("Вниз", rx + 3 * (bw2 + gap), by2, bw2, 16, () -> {
            if (selected != null) selected.look(0f, 10f);
        });
        btn("Лог вверх", rx + 4 * (bw2 + gap), by2, bw2, 16, () -> scroll += 6);
        btn("Лог вниз", rx + 5 * (bw2 + gap), by2, bw2, 16, () -> scroll = Math.max(0, scroll - 6));

        // слот удочки
        slotField = new TextFieldWidget(textRenderer, rx + rw - 26, 2, 26, 12, Text.literal("слот"));
        slotField.setMaxLength(1);
        slotField.setText(String.valueOf(selected != null ? selected.slot : 1));
        slotField.setChangedListener(s -> {
            try {
                int v = Integer.parseInt(s.trim());
                if (selected != null && v >= 1 && v <= 9) selected.slot = v;
            } catch (NumberFormatException ignored) {
            }
        });
        addDrawableChild(slotField);

        // ----- чат -----
        chatTop = 54;
        chatBottom = height - 22;
        chatField = new TextFieldWidget(textRenderer, rx, height - 18, rw - 46, 14, Text.literal("сообщение"));
        chatField.setMaxLength(256);
        addDrawableChild(chatField);
        btn("Отпр.", rx + rw - 44, height - 20, 44, 16, this::sendChat);

        // ----- капча (поверх всего) -----
        capScale = Math.max(0.6f, Math.min(2f, (height - 120) / 128f));
        capImgSize = (int) (128 * capScale);
        capOw = capImgSize + 8;
        capOh = capImgSize + 8 + 22;
        capOx = rx + (rw - capOw) / 2;
        capOy = 54;
        captchaField = new TextFieldWidget(textRenderer, capOx + 4, capOy + capImgSize + 10, Math.max(40, capOw - 8 - 36), 14,
                Text.literal("код"));
        captchaField.setMaxLength(20);
        addDrawableChild(captchaField);
        capOk = btn("ОК", capOx + capOw - 4 - 32, capOy + capImgSize + 9, 32, 16, this::sendCaptcha);
        capHide = btn("x", capOx + capOw - 16, capOy + 4, 12, 12, () -> {
            if (selected != null) selected.captcha = null;
        });
    }

    private void addBot() {
        String nick = nickField.getText().trim();
        String host = hostField.getText().trim();
        if (!nick.matches("[A-Za-z0-9_]{3,16}")) {
            if (selected != null) selected.addLog("Ник: латиница, цифры, _ (3-16 символов)");
            return;
        }
        if (host.isEmpty()) return;
        for (Bot b : BotManager.bots) {
            if (b.name.equalsIgnoreCase(nick) && b.hostPort().equalsIgnoreCase(host)) {
                client.setScreen(new BotsScreen(b));
                return;
            }
        }
        lastNick = nick;
        lastHost = host;
        Bot bot = new Bot(nick, host);
        BotManager.add(bot);
        bot.connectAsync();
        client.setScreen(new BotsScreen(bot));
    }

    private void sendChat() {
        if (selected == null) return;
        String t = chatField.getText();
        if (t.isBlank()) return;
        selected.sendChat(t);
        chatField.setText("");
        scroll = 0;
    }

    private void sendCaptcha() {
        if (selected == null) return;
        String t = captchaField.getText().trim();
        if (t.isEmpty()) return;
        selected.sendChat(t);
        captchaField.setText("");
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) {
            if (captchaField.visible && captchaField.isFocused()) {
                sendCaptcha();
                return true;
            }
            if (chatField.isFocused()) {
                sendChat();
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll += (int) Math.signum(verticalAmount) * 3;
        if (scroll < 0) scroll = 0;
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // свой фон рисуется в render()
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xFF14141C);
        ctx.fill(2, 2, leftW + 6, height - 2, 0xFF1D1D28);

        boolean cap = selected != null && selected.captcha != null;
        captchaField.visible = cap;
        captchaField.active = cap;
        capOk.visible = cap;
        capOk.active = cap;
        capHide.visible = cap;
        capHide.active = cap;

        if (selected != null) {
            fishBtn.setMessage(Text.literal(selected.fishing ? "Рыбалка: ВКЛ" : "Рыбалка: выкл"));
            ctx.drawText(textRenderer, textRenderer.trimToWidth(selected.statusLine(), rw - 60), rx, 5, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, "слот", rx + rw - 26 - 24, 5, 0xFFAAAAAA, false);
        } else {
            ctx.drawText(textRenderer, "Добавь бота слева: ник и сервер", rx, 5, 0xFFAAAAAA, false);
        }

        // чат выбранного бота
        if (selected != null) {
            List<OrderedText> wrapped = new ArrayList<>();
            for (String s : selected.lastLines(80)) {
                wrapped.addAll(textRenderer.wrapLines(Text.literal(s), rw - 6));
            }
            int lh = 10;
            int visible = Math.max(1, (chatBottom - chatTop) / lh);
            int total = wrapped.size();
            int maxScroll = Math.max(0, total - visible);
            if (scroll > maxScroll) scroll = maxScroll;
            int start = Math.max(0, total - visible - scroll);
            ctx.fill(rx - 2, chatTop - 2, rx + rw, chatBottom, 0xFF0F0F15);
            int yy = chatTop;
            for (int i = start; i < Math.min(total, start + visible); i++) {
                ctx.drawText(textRenderer, wrapped.get(i), rx + 2, yy, 0xFFFFFFFF, false);
                yy += lh;
            }
        }

        // картинка капчи
        if (cap) {
            ctx.fill(capOx, capOy, capOx + capOw, capOy + capOh, 0xFF2A2A36);
            ctx.fill(capOx + 4, capOy + 4, capOx + 4 + capImgSize, capOy + 4 + capImgSize, 0xFFDDDDDD);
            MatrixStack m = ctx.getMatrices();
            m.push();
            m.translate((float) (capOx + 4), (float) (capOy + 4), 0f);
            m.scale(capScale, capScale, 1f);
            for (int[] r : selected.captcha.rects) {
                ctx.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], r[4]);
            }
            m.pop();
        }

        super.render(ctx, mouseX, mouseY, delta);

        // индикаторы у ботов в списке
        int y = 4;
        for (Bot b : shownBots) {
            int col = b.fishing ? 0xFF55AAFF : b.inGame ? 0xFF55FF55
                    : b.status.startsWith("подключ") ? 0xFFFFFF55 : 0xFF888888;
            ctx.fill(8, y + 5, 14, y + 11, col);
            if (b == selected) ctx.fill(2, y, 4, y + 16, 0xFF55FF55);
            y += 17;
        }
    }
}
