package com.ragebots;

import org.geysermc.mcprotocollib.network.ClientSession;
import org.geysermc.mcprotocollib.network.Session;
import org.geysermc.mcprotocollib.network.event.session.DisconnectedEvent;
import org.geysermc.mcprotocollib.network.event.session.SessionAdapter;
import org.geysermc.mcprotocollib.network.factory.ClientNetworkSessionFactory;
import org.geysermc.mcprotocollib.network.packet.Packet;
import org.geysermc.mcprotocollib.protocol.MinecraftProtocol;

import java.net.InetSocketAddress;
import java.time.Instant;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class Bot {
    public static final ScheduledExecutorService EX = Executors.newScheduledThreadPool(3, r -> {
        Thread t = new Thread(r, "ragebots-worker");
        t.setDaemon(true);
        return t;
    });

    private enum Fs {IDLE, CASTING, WAITING, REELING, COOLDOWN}

    public final String name;
    public final String host;
    public final int port;

    public volatile ClientSession session;
    public volatile String status = "отключён";
    public volatile boolean inGame;
    public volatile int entityId = -1;
    public volatile float hp = -1;
    public volatile Captcha captcha;
    public final List<String> log = new CopyOnWriteArrayList<>();

    // управление
    public volatile float yaw = 0f;
    public volatile float pitch = 0f;
    public volatile int slot = 1;

    // рыбалка
    public volatile boolean fishing;
    public volatile int catches;
    private final Object lock = new Object();
    private Fs fs = Fs.IDLE;
    private int bobberId = -1;
    private long castAt;
    private long waitSince;
    private int token;
    private int seq;

    public Bot(String name, String hostPort) {
        this.name = name;
        String h = hostPort.trim();
        int p = 25565;
        int idx = h.lastIndexOf(':');
        if (idx > 0) {
            try {
                p = Integer.parseInt(h.substring(idx + 1));
                h = h.substring(0, idx);
            } catch (NumberFormatException ignored) {
            }
        }
        this.host = h;
        this.port = p;
    }

    public String hostPort() {
        return port == 25565 ? host : host + ":" + port;
    }

    public void addLog(String s) {
        if (s == null || s.isEmpty()) return;
        log.add(s);
        while (log.size() > 300) log.remove(0);
    }

    public String statusLine() {
        StringBuilder sb = new StringBuilder(name).append(" - ").append(status);
        if (hp >= 0) sb.append("  HP ").append((int) hp);
        if (fishing) sb.append("  | рыбалка: ").append(fishText()).append(" (").append(catches).append(")");
        return sb.toString();
    }

    private String fishText() {
        synchronized (lock) {
            return switch (fs) {
                case IDLE -> "ожидание";
                case CASTING -> "заброс";
                case WAITING -> "ждёт поклёвку";
                case REELING -> "подсекает";
                case COOLDOWN -> "пауза";
            };
        }
    }

    // ---------- соединение ----------

    public void connectAsync() {
        EX.execute(this::connect);
    }

    private void connect() {
        disconnect();
        try {
            status = "подключение...";
            addLog("Подключаюсь к " + hostPort() + " как " + name);
            MinecraftProtocol protocol = new MinecraftProtocol(name);
            ClientSession s = ClientNetworkSessionFactory.factory()
                    .setRemoteSocketAddress(new InetSocketAddress(host, port))
                    .setProtocol(protocol)
                    .create();
            s.addListener(new SessionAdapter() {
                @Override
                public void packetReceived(Session session, Packet packet) {
                    try {
                        handle(packet);
                    } catch (Throwable t) {
                        addLog("[ошибка пакета] " + Util.shortErr(t));
                    }
                }

                @Override
                public void disconnected(DisconnectedEvent event) {
                    inGame = false;
                    fishing = false;
                    status = "отключён";
                    String reason = Util.plain(Util.tryCall(event, "getReason"));
                    addLog("Отключён" + (reason.isEmpty() ? "" : ": " + reason));
                }
            });
            session = s;
            s.connect();
        } catch (Throwable t) {
            status = "ошибка";
            addLog("[ошибка подключения] " + Util.shortErr(t));
        }
    }

    public void disconnect() {
        ClientSession s = session;
        session = null;
        fishing = false;
        inGame = false;
        captcha = null;
        synchronized (lock) {
            fs = Fs.IDLE;
            token++;
        }
        if (s != null) {
            try {
                s.disconnect("Отключён");
            } catch (Throwable ignored) {
            }
        }
        status = "отключён";
    }

    // ---------- входящие пакеты ----------

    private void handle(Packet p) {
        String n = p.getClass().getSimpleName();
        switch (n) {
            case "ClientboundLoginPacket" -> {
                Object id = Util.tryCall(p, "getEntityId");
                if (id instanceof Number num) entityId = num.intValue();
                inGame = true;
                status = "в игре";
                addLog("Зашёл на сервер");
            }
            case "ClientboundSystemChatPacket" -> {
                Object ov = Util.tryCall(p, "isOverlay");
                if (!(ov instanceof Boolean b && b)) onChat(Util.plain(Util.tryCall(p, "getContent")));
            }
            case "ClientboundPlayerChatPacket" -> {
                String who = Util.plain(Util.tryCall(p, "getName"));
                Object uc = Util.tryCall(p, "getUnsignedContent");
                String msg = uc != null ? Util.plain(uc) : String.valueOf(Util.tryCall(p, "getContent"));
                onChat(who + ": " + msg);
            }
            case "ClientboundDisguisedChatPacket" -> {
                String who = Util.plain(Util.tryCall(p, "getName"));
                String msg = Util.plain(Util.tryCall(p, "getMessage"));
                onChat(who.isEmpty() ? msg : who + ": " + msg);
            }
            case "ClientboundLoginDisconnectPacket", "ClientboundDisconnectPacket" ->
                    addLog("Кик: " + Util.plain(Util.tryCall(p, "getReason")));
            case "ClientboundMapItemDataPacket" -> onMap(p);
            case "ClientboundAddEntityPacket" -> onAddEntity(p);
            case "ClientboundSetEntityMotionPacket" -> onMotion(p);
            case "ClientboundRemoveEntitiesPacket" -> onRemove(p);
            case "ClientboundSetHealthPacket" -> {
                Object h = Util.tryCall(p, "getHealth");
                if (h instanceof Number num) hp = num.floatValue();
            }
            default -> {
            }
        }
    }

    private void onChat(String text) {
        if (text == null || text.isEmpty()) return;
        addLog(text);
        String low = text.toLowerCase();
        if (captcha != null && (low.contains("проверка пройдена") || low.contains("приятной игры"))) {
            captcha = null;
        }
    }

    private void onMap(Packet p) {
        Object data = Util.tryCall(p, "getData");
        if (data == null) return;
        Object colsO = Util.tryCall(data, "getColumns");
        Object rowsO = Util.tryCall(data, "getRows");
        Object xO = Util.tryCall(data, "getX");
        Object yO = Util.tryCall(data, "getY");
        Object arr = Util.tryCall(data, "getData");
        if (!(colsO instanceof Number) || !(arr instanceof byte[] bytes)) return;
        int cols = ((Number) colsO).intValue();
        int rows = rowsO instanceof Number r ? r.intValue() : 0;
        int x0 = xO instanceof Number xx ? xx.intValue() : 0;
        int y0 = yO instanceof Number yy ? yy.intValue() : 0;
        if (cols <= 0 || rows <= 0) return;
        byte[] map = new byte[128 * 128];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int dx = x0 + j, dy = y0 + i;
                int src = i * cols + j;
                if (dx < 128 && dy < 128 && src < bytes.length) map[dy * 128 + dx] = bytes[src];
            }
        }
        captcha = Captcha.from(map);
        addLog("Пришла картинка (капча?). Введи цифры в окне и нажми ОК.");
    }

    private void onAddEntity(Packet p) {
        if (!fishing) return;
        String type = String.valueOf(Util.tryCall(p, "getType")).toUpperCase();
        if (!type.contains("FISHING")) return;
        Object idO = Util.tryCall(p, "getEntityId");
        if (!(idO instanceof Number)) return;
        int id = ((Number) idO).intValue();
        Object owner = Util.tryCall(Util.tryCall(p, "getData"), "getOwnerId");
        long now = System.currentTimeMillis();
        int t;
        synchronized (lock) {
            if (fs != Fs.CASTING) return;
            if (owner instanceof Number on && entityId >= 0 && on.intValue() != entityId) return;
            if (!(owner instanceof Number) && now - castAt > 3500) return;
            bobberId = id;
            fs = Fs.WAITING;
            waitSince = now;
            t = token;
        }
        EX.schedule(() -> waitTimeout(t), 75, TimeUnit.SECONDS);
    }

    private void onMotion(Packet p) {
        if (!fishing) return;
        Object idO = Util.tryCall(p, "getEntityId");
        Object my = Util.tryCall(p, "getMotionY");
        if (!(idO instanceof Number) || !(my instanceof Number)) return;
        int t;
        synchronized (lock) {
            if (fs != Fs.WAITING || ((Number) idO).intValue() != bobberId) return;
            if (System.currentTimeMillis() - waitSince < 1200) return;
            if (((Number) my).doubleValue() > -0.12) return;
            fs = Fs.REELING;
            t = token;
        }
        EX.schedule(() -> reel(t), rnd(350, 850), TimeUnit.MILLISECONDS);
    }

    private void onRemove(Packet p) {
        if (!fishing) return;
        Object ids = Util.tryCall(p, "getEntityIds");
        if (!(ids instanceof int[] arr)) return;
        boolean hit = false;
        synchronized (lock) {
            if (fs == Fs.WAITING) {
                for (int i : arr) {
                    if (i == bobberId) hit = true;
                }
                if (hit) {
                    fs = Fs.COOLDOWN;
                    bobberId = -1;
                }
            }
        }
        if (hit) EX.schedule(this::cast, rnd(1500, 3000), TimeUnit.MILLISECONDS);
    }

    // ---------- отправка ----------

    private void send(String simple, Object[]... candidates) {
        ClientSession s = session;
        if (s == null) return;
        try {
            Object pk = Util.construct(simple, candidates);
            s.send((Packet) pk);
        } catch (Throwable t) {
            addLog("[ошибка отправки " + simple + "] " + Util.shortErr(t));
        }
    }

    public void sendChat(String msg) {
        if (msg == null || msg.isBlank()) return;
        if (!inGame) {
            addLog("Бот ещё не в игре");
            return;
        }
        addLog("> " + msg);
        if (msg.startsWith("/")) {
            send("ServerboundChatCommandPacket", new Object[]{msg.substring(1)});
        } else {
            send("ServerboundChatPacket", new Object[]{msg, Instant.now(), 0L, null, 0, new BitSet()});
        }
    }

    public void look(float dYaw, float dPitch) {
        yaw = ((yaw + dYaw) % 360f + 360f) % 360f;
        pitch = Math.max(-90f, Math.min(90f, pitch + dPitch));
        sendRotation();
        addLog("Поворот: yaw " + (int) yaw + ", pitch " + (int) pitch);
    }

    private void sendRotation() {
        Float y = yaw, p = pitch;
        send("ServerboundMovePlayerRotPacket",
                new Object[]{Boolean.TRUE, Boolean.FALSE, y, p},
                new Object[]{Boolean.TRUE, y, p});
    }

    private void selectSlot() {
        int s = Math.max(1, Math.min(9, slot)) - 1;
        send("ServerboundSetCarriedItemPacket", new Object[]{s});
    }

    private void useItem() {
        Object hand = Util.mainHand();
        Float y = yaw, p = pitch;
        int sq = ++seq;
        send("ServerboundUseItemPacket",
                new Object[]{hand, sq, y, p},
                new Object[]{hand, sq});
    }

    // ---------- рыбалка ----------

    public void setFishing(boolean on) {
        if (on) {
            if (!inGame) {
                addLog("Рыбалка: бот не в игре");
                return;
            }
            synchronized (lock) {
                fishing = true;
                fs = Fs.IDLE;
                bobberId = -1;
                token++;
            }
            addLog("Рыбалка: вкл (удочка в слоте " + slot + ")");
            selectSlot();
            sendRotation();
            EX.schedule(this::cast, rnd(500, 2500), TimeUnit.MILLISECONDS);
        } else {
            boolean pull;
            synchronized (lock) {
                pull = fishing && fs == Fs.WAITING;
                fishing = false;
                fs = Fs.IDLE;
                bobberId = -1;
                token++;
            }
            if (pull) useItem();
            addLog("Рыбалка: выкл");
        }
    }

    private void cast() {
        int t;
        synchronized (lock) {
            if (!fishing || !inGame) return;
            fs = Fs.CASTING;
            castAt = System.currentTimeMillis();
            bobberId = -1;
            t = ++token;
        }
        useItem();
        EX.schedule(() -> castTimeout(t), 6, TimeUnit.SECONDS);
    }

    private void castTimeout(int t) {
        synchronized (lock) {
            if (!fishing || t != token || fs != Fs.CASTING) return;
            fs = Fs.COOLDOWN;
        }
        addLog("Поплавок не появился, пробую снова");
        EX.schedule(this::cast, rnd(2000, 3500), TimeUnit.MILLISECONDS);
    }

    private void waitTimeout(int t) {
        synchronized (lock) {
            if (!fishing || t != token || fs != Fs.WAITING) return;
            fs = Fs.COOLDOWN;
            bobberId = -1;
        }
        addLog("Долго нет поклёвки, перезабрасываю");
        useItem();
        EX.schedule(this::cast, rnd(1500, 3000), TimeUnit.MILLISECONDS);
    }

    private void reel(int t) {
        synchronized (lock) {
            if (!fishing || t != token || fs != Fs.REELING) return;
            fs = Fs.COOLDOWN;
            bobberId = -1;
        }
        useItem();
        catches++;
        addLog("Подсёк (" + catches + ")");
        EX.schedule(this::cast, rnd(1500, 3500), TimeUnit.MILLISECONDS);
    }

    private static long rnd(int a, int b) {
        return ThreadLocalRandom.current().nextLong(a, b + 1);
    }

    public List<String> lastLines(int n) {
        List<String> copy = new ArrayList<>(log);
        int from = Math.max(0, copy.size() - n);
        return copy.subList(from, copy.size());
    }
}
