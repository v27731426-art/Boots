package com.ragebots;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class BotManager {
    private BotManager() {}

    public static final List<Bot> bots = new CopyOnWriteArrayList<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ragebots.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonArray arr = JsonParser.parseString(Files.readString(f)).getAsJsonArray();
            for (var e : arr) {
                JsonObject o = e.getAsJsonObject();
                bots.add(new Bot(o.get("name").getAsString(), o.get("host").getAsString()));
            }
        } catch (Throwable ignored) {
        }
    }

    public static void save() {
        try {
            JsonArray arr = new JsonArray();
            for (Bot b : bots) {
                JsonObject o = new JsonObject();
                o.addProperty("name", b.name);
                o.addProperty("host", b.hostPort());
                arr.add(o);
            }
            Files.writeString(file(), arr.toString());
        } catch (Throwable ignored) {
        }
    }

    public static void add(Bot b) {
        bots.add(b);
        save();
    }

    public static void remove(Bot b) {
        b.disconnect();
        bots.remove(b);
        save();
    }
}
