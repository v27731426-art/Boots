package com.ragebots;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

/** Вспомогательные функции: пакеты и тексты достаются через рефлексию, чтобы мелкие отличия версий библиотеки не ломали сборку. */
public final class Util {
    private Util() {}

    private static final String BASE = "org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.";
    private static final String[] PKGS = {
            BASE, BASE + "player.", BASE + "level.", BASE + "inventory.", BASE + "entity."
    };
    private static final String HAND = "org.geysermc.mcprotocollib.protocol.data.game.entity.player.Hand";

    public static Class<?> packetClass(String simple) {
        for (String p : PKGS) {
            try {
                return Class.forName(p + simple, false, Util.class.getClassLoader());
            } catch (ClassNotFoundException ignored) {
            }
        }
        throw new IllegalStateException("класс пакета не найден: " + simple);
    }

    public static Object mainHand() {
        try {
            Class<?> c = Class.forName(HAND, false, Util.class.getClassLoader());
            Object[] all = c.getEnumConstants();
            for (Object o : all) {
                if (((Enum<?>) o).name().equals("MAIN_HAND")) return o;
            }
            return all[0];
        } catch (Exception e) {
            throw new IllegalStateException("класс Hand не найден");
        }
    }

    /** Создаёт пакет, пробуя по очереди наборы аргументов (на случай разных версий конструктора). */
    public static Object construct(String simple, Object[]... candidates) throws Exception {
        Class<?> c = packetClass(simple);
        for (Object[] args : candidates) {
            for (Constructor<?> k : c.getConstructors()) {
                Class<?>[] pt = k.getParameterTypes();
                if (pt.length != args.length) continue;
                boolean ok = true;
                for (int i = 0; i < pt.length; i++) {
                    if (!compatible(pt[i], args[i])) {
                        ok = false;
                        break;
                    }
                }
                if (ok) return k.newInstance(args);
            }
        }
        throw new IllegalStateException("нет подходящего конструктора для " + simple + ": " + Arrays.toString(c.getConstructors()));
    }

    private static boolean compatible(Class<?> p, Object a) {
        if (a == null) return !p.isPrimitive();
        if (p.isPrimitive()) return box(p).isInstance(a);
        return p.isInstance(a);
    }

    private static Class<?> box(Class<?> p) {
        if (p == int.class) return Integer.class;
        if (p == long.class) return Long.class;
        if (p == float.class) return Float.class;
        if (p == double.class) return Double.class;
        if (p == boolean.class) return Boolean.class;
        if (p == byte.class) return Byte.class;
        if (p == short.class) return Short.class;
        if (p == char.class) return Character.class;
        return p;
    }

    public static Object tryCall(Object o, String name) {
        if (o == null) return null;
        try {
            Method m = o.getClass().getMethod(name);
            m.setAccessible(true);
            return m.invoke(o);
        } catch (Throwable t) {
            return null;
        }
    }

    public static String plain(Object c) {
        if (c == null) return "";
        if (c instanceof CharSequence) return clean(c.toString());
        StringBuilder sb = new StringBuilder();
        flatten(c, sb, 0);
        return clean(sb.toString());
    }

    private static void flatten(Object c, StringBuilder sb, int depth) {
        if (c == null || depth > 24) return;
        Object content = tryCall(c, "content");
        if (content instanceof String s) {
            sb.append(s);
        } else {
            Object key = tryCall(c, "key");
            if (key instanceof String k) sb.append(k);
        }
        Object ch = tryCall(c, "children");
        if (ch instanceof Iterable<?> it) {
            for (Object o : it) flatten(o, sb, depth + 1);
        }
    }

    public static String clean(String s) {
        return s.replaceAll("§.", "").replace('\n', ' ').trim();
    }

    public static String shortErr(Throwable t) {
        while (t instanceof InvocationTargetException && t.getCause() != null) t = t.getCause();
        return t.getClass().getSimpleName() + ": " + t.getMessage();
    }
}
