package com.ragebots;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class RageBotsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BotManager.load();

        // /bots в чате открывает окно
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("bots").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new BotsScreen(null)));
                    return 1;
                })));

        // клавиша B тоже открывает окно
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ragebots.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.ragebots"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.wasPressed()) {
                client.setScreen(new BotsScreen(null));
            }
        });
    }
}
