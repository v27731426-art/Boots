package com.ragebots;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Картинка капчи из данных карты, заранее разложенная на прямоугольники для быстрой отрисовки. */
public final class Captcha {
    /** {x, y, w, h, argb} */
    public final List<int[]> rects = new ArrayList<>();

    public static Captcha from(byte[] map) {
        int n = 128 * 128;
        int[] px = new int[n];
        Map<Integer, Integer> cnt = new HashMap<>();
        for (int i = 0; i < n; i++) {
            px[i] = MapColors.argb(map[i] & 0xFF);
            if ((px[i] >>> 24) != 0) cnt.merge(px[i], 1, Integer::sum);
        }
        int mode = 0, best = 0;
        for (Map.Entry<Integer, Integer> e : cnt.entrySet()) {
            if (e.getValue() > best) {
                best = e.getValue();
                mode = e.getKey();
            }
        }
        boolean useBg = best > n * 0.3;
        Captcha c = new Captcha();
        if (useBg) c.rects.add(new int[]{0, 0, 128, 128, mode});
        for (int y = 0; y < 128; y++) {
            int x = 0;
            while (x < 128) {
                int col = px[y * 128 + x];
                if ((col >>> 24) == 0 || (useBg && col == mode)) {
                    x++;
                    continue;
                }
                int x2 = x;
                while (x2 < 128 && px[y * 128 + x2] == col) x2++;
                c.rects.add(new int[]{x, y, x2 - x, 1, col});
                x = x2;
            }
        }
        return c;
    }
}
